from __future__ import annotations

from pyspark.sql import functions as F

from .abstract import Extension
from ..dataset.backends import PandasDataset, SparkDataset
from ..utils.registry import backend_factory


class MatchingMetricsExtension(Extension):
    def __init__(self):
        super().__init__()

    def calc(self, data, **kwargs):
        ...


@backend_factory.register(MatchingMetricsExtension, PandasDataset)
class PandasMatchingMetricsExtension(MatchingMetricsExtension):
    """
    """

@backend_factory.register(MatchingMetricsExtension, SparkDataset)
class SparkMatchingMetricsExtension(MatchingMetricsExtension):
    """
    """
#  calc stats:


# # Spark не пересчитывал граф вычислений дважды
# itt.persist()
# itc.persist()

# itt_col = itt.columns[0]
# itc_col = itc.columns[0]

# # 2. Получаем нативные Spark DataFrame (избегаем pyspark.pandas)
# itt_spark = itt._backend_data.data.to_spark()
# itc_spark = itc._backend_data.data.to_spark()

# # 3. Считаем статистики одним проходом через нативный Spark SQL
# # F.variance сразу считает дисперсию, убираем лишнее возведение в квадрат (std**2)
# itt_row = itt_spark.select(
#     F.count(F.col(itt_col)).alias("count"),
#     F.mean(F.col(itt_col)).alias("mean"),
#     F.variance(F.col(itt_col)).alias("var") 
# ).collect()[0]

# itc_row = itc_spark.select(
#     F.count(F.col(itc_col)).alias("count"),
#     F.mean(F.col(itc_col)).alias("mean"),
#     F.variance(F.col(itc_col)).alias("var")
# ).collect()[0]

# itt_c, itt_mean, var_t = itt_row["count"], itt_row["mean"], itt_row["var"]
# itc_c, itc_mean, var_c = itc_row["count"], itc_row["mean"], itc_row["var"]

# # 4. Освобождаем память
# itt.unpersist()
# itc.unpersist()