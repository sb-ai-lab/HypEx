from __future__ import annotations
import hnswlib
import numpy as np
import gc
import os
import uuid
from typing import Literal
from ..dataset import Dataset
from ..utils.registry import backend_factory
from .abstract import MLExtension
from ..dataset.backends import PandasDataset, SparkDataset
import pyspark.sql.functions as F
from pyspark import SparkFiles


class HNSWExtension(MLExtension):
    """Master class for HNSW nearest neighbors."""
    
    def __init__(
        self,
        n_neighbors: int = 10,
        ef_construction: int = 200,
        M: int = 16,
        metric: str = "l2",
    ):
        self.n_neighbors = n_neighbors
        self.ef_construction = ef_construction
        self.M = M
        self.metric = metric
        self.index = None
        super().__init__()
    
    def calc(self, data: Dataset, test_data: Dataset | None = None, **kwargs):
        raise NotImplementedError


@backend_factory.register(HNSWExtension, PandasDataset)
class PandasHNSWExtension(HNSWExtension):
    """Простая и быстрая реализация на Pandas."""
    
    def _fit(self, data: Dataset):
        X = data.data.values.astype(np.float32)
        dim = X.shape[1]
        
        self.index = hnswlib.Index(space=self.metric, dim=dim)
        self.index.init_index(
            max_elements=len(X),
            ef_construction=self.ef_construction,
            M=self.M
        )
        self.index.add_items(X, data.index.astype(np.int64).values)
    
    def _predict(self, test_data: Dataset) -> Dataset:
        X_query = test_data.data.values.astype(np.float32)
        labels, distances = self.index.knn_query(X_query, k=self.n_neighbors)
        
        # Формируем результат
        result_dict = {f"match_{i+1}": labels[:, i] for i in range(self.n_neighbors)}
        result_dict["distances"] = distances.mean(axis=1)  # optional
        
        return self.result_to_dataset(result_dict, roles={}).set_index(test_data.index)
    
    def calc(self, data: Dataset, test_data: Dataset | None = None, mode: str = "auto"):
        mode = mode or "auto"
        
        if mode in ("auto", "fit"):
            self._fit(data)
        
        if mode in ("auto", "predict"):
            if test_data is None:
                raise ValueError("test_data required")
            return self._predict(test_data)
        
        return self


def _hnsw_predict_partition(iterator, index_file, n_neighbors, ef_search):
    """Функция для предсказания на каждой партиции Spark."""
    import hnswlib
    import numpy as np
    
    # Загружаем индекс из файла
    index = hnswlib.Index(space='l2', dim=0)  # dim будет определен при загрузке
    
    # Читаем данные из партиции
    rows = list(iterator)
    if not rows:
        return []
    
    # Извлекаем индексы и данные
    indices = np.array([row['index'] for row in rows], dtype=np.int64)
    X_query = np.array([list(row['features']) for row in rows], dtype=np.float32)
    
    # Загружаем индекс
    index.load_index(index_file, max_elements=len(X_query))
    index.set_ef(ef_search)
    
    # Делаем предсказания
    labels, distances = index.knn_query(X_query, k=n_neighbors)
    
    # Формируем результат
    results = []
    for i in range(len(rows)):
        result = {
            'index': int(indices[i]),
            'matches': labels[i].tolist(),
            'distances': distances[i].tolist()
        }
        results.append(result)
    
    return results


@backend_factory.register(HNSWExtension, SparkDataset)
class SparkHNSWExtension(HNSWExtension):
    """Распределенная Spark-реализация с broadcast индекса."""
    
    def _fit_and_save_index(self, data: Dataset) -> str:
        """Строит индекс на драйвере и сохраняет в файл."""
        # Собираем данные на драйвер
        pdf = data.data.toPandas()
        X = pdf.values.astype(np.float32)
        indices = pdf.index.astype(np.int64).values
        
        dim = X.shape[1]
        
        # Строим индекс
        index = hnswlib.Index(space=self.metric, dim=dim)
        index.init_index(
            max_elements=len(X),
            ef_construction=self.ef_construction,
            M=self.M
        )
        index.add_items(X, indices)
        
        # Сохраняем индекс в файл
        index_file = f"/tmp/hnsw_index_{uuid.uuid4().hex[:8]}.bin"
        index.save_index(index_file)
        
        return index_file
    
    def calc(self, data: Dataset, test_data: Dataset | None = None, **kwargs):
        if test_data is None:
            # Только fit
            self._fit(data)
            return self
        
        # Строим индекс на драйвере
        index_file = self._fit_and_save_index(data)
        
        try:
            # Подготавливаем тестовые данные
            session = test_data.data.to_spark().sparkSession
            
            # Добавляем файл индекса в SparkFiles
            session.sparkContext.addFile(f"file://{index_file}")
            index_file_distributed = SparkFiles.get(os.path.basename(index_file))
            
            # Подготавливаем тестовые данные
            test_spark = test_data.data.to_spark()
            
            # Добавляем колонку с индексом
            if 'index' not in test_spark.columns:
                test_spark = test_spark.withColumn('index', F.monotonically_increasing_id())
            
            # Переименовываем колонки в features
            feature_cols = [c for c in test_spark.columns if c != 'index']
            test_spark = test_spark.withColumn('features', F.array(*feature_cols))
            
            # Делаем предсказания распределенно
            result_rdd = test_spark.rdd.mapPartitions(
                lambda it: _hnsw_predict_partition(
                    it,
                    index_file_distributed,
                    self.n_neighbors,
                    self.ef_construction  # ef_search обычно = ef_construction
                )
            )
            
            # Собираем результаты
            results = result_rdd.collect()
            
            # Формируем итоговый DataFrame
            all_matches = []
            all_distances = []
            all_indices = []
            
            for partition_result in results:
                for row in partition_result:
                    all_indices.append(row['index'])
                    all_matches.append(row['matches'])
                    all_distances.append(row['distances'])
            
            # Создаем результирующий DataFrame
            result_dict = {}
            for i in range(self.n_neighbors):
                result_dict[f"match_{i+1}"] = [m[i] for m in all_matches]
            result_dict["distances"] = [np.mean(d) for d in all_distances]
            
            # Конвертируем в Dataset
            import pandas as pd
            result_pdf = pd.DataFrame(result_dict, index=all_indices)
            
            return self.result_to_dataset(result_pdf, roles={})
        
        finally:
            # Удаляем временный файл
            if os.path.exists(index_file):
                os.remove(index_file)