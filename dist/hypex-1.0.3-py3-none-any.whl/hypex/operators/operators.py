from __future__ import annotations

from copy import deepcopy
from typing import Any, Literal

import numpy as np
import time

from ..dataset import (
    ABCRole,
    AdditionalMatchingRole,
    AdditionalTargetRole,
    AdditionalFeatureRole,
    Dataset,
    SmallDataset,
    ExperimentData,
    FeatureRole,
    InfoRole,
    TargetRole,
    AdditionalStatisticRole
)
from ..extensions.scipy_stats import NormCDF
from ..extensions.scipy_linalg import LstsqExtension
from ..extensions import BiasExtension, MatchingMetricsExtension
from ..utils import ID_SPLIT_SYMBOL
from ..utils.enums import ExperimentDataEnum
from ..utils.errors import NoneArgumentError
from ..utils.registry import backend_factory
from .abstract import GroupOperator


class SMD(GroupOperator):
    def execute(self, data: ExperimentData) -> ExperimentData:
        pass

    @classmethod
    def _inner_function(
        cls, data: Dataset, test_data: Dataset | None = None, **kwargs
    ) -> Any:
        test_data = cls._check_test_data(test_data=test_data)
        return (data.mean() + test_data.mean()) / data.std()


class MatchingMetrics(GroupOperator):
    """
    Calculator for estimating treatment effects (ATT, ATC, ATE) and their 
    statistical significance after matching.

    This class computes the Individual Treatment Effect on the Treated (ITT) 
    and Control (ITC), applies optional bias correction, and calculates the 
    final Average Treatment Effects along with their standard errors, p-values, 
    and confidence intervals. It also handles the calculation of scaled counts 
    (weights) to account for multiple matches or specific matching strategies.

    Inherits from:
        GroupOperator: The base class for group-based operators in the HypEx library.
    """
    def __init__(
        self,
        grouping_role: ABCRole | None = None,
        target_roles: ABCRole | list[ABCRole] | None = None,
        metric: Literal["auto", "atc", "att", "ate"] | None = None,
        n_neighbors: int = 1,
        key: Any = "",
    ):
        """
        Initialize the matching metrics calculator.

        Args:
            grouping_role (ABCRole | None, optional): The role defining the grouping 
                column. Defaults to None.
            target_roles (ABCRole | list[ABCRole] | None, optional): The role(s) 
                defining the target column(s). Defaults to None.
            metric (Literal["auto", "atc", "att", "ate"] | None, optional): The type 
                of treatment effect to estimate. "atc" = average treatment effect on 
                controls, "att" = average treatment effect on treated, "ate" = average 
                treatment effect, "auto" = calculates all. Defaults to "auto".
            n_neighbors (int, optional): The number of neighbors used in the matching 
                process, used for scaling counts. Defaults to 1.
            key (Any, optional): Optional identifier for the operator instance. 
                Defaults to "".
        """
        self.metric = metric or "auto"
        self.n_neighbors = n_neighbors
        self.__scaled_counts = {}
        target_roles = target_roles or TargetRole()
        super().__init__(
            grouping_role=grouping_role,
            target_roles=(
                target_roles if isinstance(target_roles, list) else [target_roles]
            ),
            key=key,
        )
    
    def _write_log(file: str, result: str, time: str, mode: str = "a"):
        with open(file, mode) as f:
            f.write(result + ": " + time + "\n")
         
    @classmethod
    def _inner_function(
        cls,
        data: Dataset,
        test_data: Dataset | None = None,
        target_fields: list[str] | None = None,
        **kwargs,
    ) -> Any:
        """
        Core calculation logic for treatment effects.

        Computes the Individual Treatment Effect on the Treated (ITT) and Control (ITC), 
        applies optional bias correction, and calculates the final metrics (ATT, ATC, ATE) 
        along with their standard errors, p-values, and 95% confidence intervals.

        Args:
            data (Dataset): The baseline (control) dataset.
            test_data (Dataset | None, optional): The compared (treatment) dataset. 
                Defaults to None.
            target_fields (list[str] | None, optional): The names of the target fields 
                to calculate effects on. Defaults to None.
            **kwargs: Additional keyword arguments, including:
                - `metric` (str): The type of effect to estimate ("att", "atc", "ate").
                - `scaled_counts` (dict): Pre-calculated scaled counts for weighting.
                - `bias` (dict | None): Optional bias correction values.

        Returns:
            Any: A dictionary containing the calculated metrics. Keys depend on the 
            `metric` argument and include effect size, standard error, p-value, and 
            lower/upper confidence interval bounds.
        """
        file = "metric_logger.txt"

        if target_fields is None or test_data is None:
            raise NoneArgumentError(
                ["target_fields", "test_data"], "att, atc, ate estimation"
            )
        metric = kwargs.get("metric", "ate")
        scaled_counts = kwargs.get("scaled_counts")
        itt: Dataset = test_data[target_fields[0]] - test_data[target_fields[1]]
        itc: Dataset = data[target_fields[1]] - data[target_fields[0]]

        bias = kwargs.get("bias", {})
        if bias and len(bias) > 0:
            if metric in ["atc", "ate"]:
                itc -= bias["control"]
            if metric in ["att", "ate"]:
                itt += bias["test"]

        # TODO: now we wish that no `nan` values will appear in target columns 
        # But just in case fill all nans by zero. The `nan` fix should be more accurate
        itt_stats = itt.fillna(0).agg(["count", "mean", "std"]).to_dict()["data"]
        itc_stats = itc.fillna(0).agg(["count", "mean", "std"]).to_dict()["data"]

        itc_c, itc_mean, var_c = itc_stats["data"][itc.columns[0]]
        itt_c, itt_mean, var_t = itt_stats["data"][itt.columns[0]]
        var_c, var_t = var_c ** 2, var_t ** 2
    
        weights = cls._calc_weights(scaled_counts)
        itt_se = cls._calc_se(
            n_c=itc_c, n_t=itt_c, var_c=var_c, var_t=var_t, 
            w_c=itt_c,
            w_t=(itt_c / itc_c) ** 2 * weights["test"]["sq_sum"]
        )
        itc_se = cls._calc_se(
            n_c=itt_c, n_t=itc_c, var_c=var_t, var_t=var_c,
            w_c=(itc_c / itt_c) ** 2 * weights["control"]["sq_sum"],
            w_t=itt_c
        )
        itt: float = itt_mean
        itc: float = itc_mean
        p_val_itt = cls._calc_p_value(itt / itt_se)
        p_val_itc = cls._calc_p_value(itc / itc_se)

        if metric == "atc":
            return {
                "ATC": [
                    itc,
                    itc_se,
                    p_val_itc,
                    itc - 1.96 * itc_se,
                    itc + 1.96 * itc_se,
                ]
            }
        if metric == "att":
            return {
                "ATT": [
                    itt,
                    itt_se,
                    p_val_itt,
                    itt - 1.96 * itt_se,
                    itt + 1.96 * itt_se,
                ]
            }
        len_control, len_test = itc_c, itt_c
        ate = (itt * len_test + itc * len_control) / (len_test + len_control)
        ate_se = cls._calc_se(
            n_c=itc_c + itt_c, n_t=itc_c + itt_c, var_c=var_c, var_t=var_t,
            w_c=itc_c + 2 * weights["control"]["sum"] + weights["control"]["sq_sum"],
            w_t=itt_c + 2 * weights["test"]["sum"] + weights["test"]["sq_sum"]
        )
        p_val_ate = cls._calc_p_value(ate / ate_se)

        return {
            "ATT": [itt, itt_se, p_val_itt, itt - 1.96 * itt_se, itt + 1.96 * itt_se],
            "ATC": [itc, itc_se, p_val_itc, itc - 1.96 * itc_se, itc + 1.96 * itc_se],
            "ATE": [ate, ate_se, p_val_ate, ate - 1.96 * ate_se, ate + 1.96 * ate_se],
        }

    @classmethod
    def _execute_inner_function(
        cls, grouping_data, target_fields: list[str] | None = None, **kwargs
    ) -> dict:
        """
        Wrapper to execute the inner function over the grouped data.

        Args:
            grouping_data: Grouped dataset containing the control and treatment slices.
            target_fields (list[str] | None, optional): The names of the target fields. 
                Defaults to None.
            **kwargs: Additional keyword arguments passed to `_inner_function`.

        Returns:
            dict: The result of the `_inner_function` calculation.
        """
        metric = kwargs.get("metric", "ate")
        if target_fields is None or len(target_fields) != 2:
            raise ValueError(
                f"This operator works with 2 targets, but got {len(target_fields) if target_fields else None}"
            )
        return cls._inner_function(
            data=grouping_data[0][1],
            test_data=grouping_data[1][1],
            target_fields=target_fields,
            metric=metric,
            bias=kwargs.get("bias_estimation", None),
            scaled_counts=kwargs.get("scaled_counts"),
        )

    def execute(self, data: ExperimentData) -> ExperimentData:
        """
        Main execution method for calculating matching metrics.

        Orchestrates the calculation process: retrieves fields, prepares targets 
        if necessary (e.g., when a second target is missing), calculates the metrics 
        using the `calc` method, and stores the results in the `ExperimentData` object.

        Args:
            data (ExperimentData): The experiment data containing the matched dataset.

        Returns:
            ExperimentData: The updated ExperimentData object with the calculated 
            matching metrics stored in the `variables` space.
        """
        group_field, target_fields = self._get_fields(data=data)
        # bias = data.field_search(AdditionalStatisticRole())
        # if len(bias) > 0:
        #     bias_groups = list(
        #         data.initial_ds[group_field]
        #         .merge(right=data.additional_fields[bias], left_index=True, right_index=True)
        #         .groupby(group_field)
        #     )
        #     bias = {
        #         "control": bias_groups[0][1][bias],
        #         "test": bias_groups[1][1][bias]
        #     }

        # else:
        #     bias = None
            
        # t_data = deepcopy(data.initial_ds)
        # if len(target_fields) != 2:
        #     matched_data = self._prepare_new_target(data, t_data, group_field)
        #     matched_data.persist()
        #     target_fields += [matched_data.search_columns(TargetRole())[0]]
        #     data.set_value(
        #         ExperimentDataEnum.additional_fields,
        #         self.id,
        #         matched_data,
        #         role=AdditionalTargetRole(),
        #     )
        #     t_data = t_data.add_column(
        #         # matched_data.reindex(t_data.index), 
        #         matched_data,
        #         role={target_fields[1]: TargetRole()},
        #     )
        #     storage_level = data.initial_ds.get_storage_level() or "MEMORY_AND_DISK"
        #     matched_data.unpersist()
        #     t_data.persist(storage_level=storage_level, action="none")
        self.key = str(
            target_fields[0] if len(target_fields) == 1 else (target_fields or "")
        )
        if (
            not target_fields and data.initial_ds.tmp_roles
        ):  # if the column is not suitable for the test, then the target will be empty, but if there is a role tempo, then this is normal behavior
            return data

        cls = backend_factory.resolve_backend(MatchingMetricsExtension, data.ds)
        compare_result = cls(self.grouping_role, self.target_roles, self.metric, self.n_neighbors).calc(data.ds)
        # compare_result = self.calc(
        #     data=t_data,
        #     group_field=group_field,
        #     target_fields=target_fields,
        #     metric=self.metric,
        #     bias_estimation=bias,
        #     scaled_counts=self.__scaled_counts,
        # )
        # if len(target_fields) != 2:
        #     if t_data.is_persisted:
        #         t_data.unpersist()
        return self._set_value(data, compare_result)


class Bias(GroupOperator):
    """
    Calculator for estimating selection bias after matching.

    This operator quantifies the residual bias between treatment and control
    groups that remains after the matching procedure. It uses a linear
    regression model (via ``LstsqExtension``) trained on the matched sample
    to predict the counterfactual outcome, then computes the difference
    between the observed and predicted values.

    The bias is defined as:
        - For treatment group:  bias_t = E[Y(0) | T=1] - E[Y(0) | T=0]
        - For control group:    bias_c = E[Y(1) | T=1] - E[Y(1) | T=0]

    where Y(0) and Y(1) are potential outcomes under control and treatment,
    and T is the treatment assignment indicator.

    The computation proceeds as follows:
        1. For each group, fit a linear model: target ~ features
           using the matched observations as the training signal.
        2. Compute the matched (counterfactual) features by averaging
           over the matched pairs for each observation.
        3. Estimate bias as: (X - X_matched) · coefficients,
           where X are the original features and X_matched are the
           pair-averaged features.

    The operator automatically handles cases where one group lacks
    matched observations (e.g., one-sided matching) by computing bias
    only for the group with available matched data.

    Inherits from:
        GroupOperator: The base class for group-based operators in the HypEx library.

    Examples:
        ```python
            # Typically used internally by the Matching pipeline
            from hypex.operators import Bias
            from hypex.dataset import TreatmentRole, TargetRole

            bias_calc = Bias(
                grouping_role=TreatmentRole(),
                target_roles=[TargetRole()],
            )
            result = bias_calc.execute(experiment_data)
        ```
    Args:
        grouping_role (ABCRole | None, optional): The role defining the
            treatment assignment column (e.g., ``TreatmentRole()``).
            Defaults to None, which falls back to ``GroupingRole()``.
        target_roles (list[ABCRole] | None, optional): The role(s) defining
            the target outcome column(s) for which bias should be estimated.
            Defaults to None, which falls back to ``TargetRole()``.
        key (Any, optional): Optional identifier for the operator instance.
            Defaults to "".

    Attributes:
        calc_bias (staticmethod): Core computation that applies the dot
            product between feature differences and regression coefficients.
        prepare_data (staticmethod): Helper that constructs the matched
            dataset by exploding match indices and aggregating features.

    See Also:
        MatchingMetrics: The operator that uses the bias estimates to
            compute bias-corrected treatment effects (ATT, ATC, ATE).
        LstsqExtension: The backend-agnostic least-squares solver used
            to fit the regression coefficients.
    """
    def __init__(
        self,
        grouping_role: ABCRole | None = None,
        target_roles: list[ABCRole] | None = None,
        key: Any = "",
    ):
        """
        Initialize the Bias calculator.

        Args:
            grouping_role (ABCRole | None, optional): The role defining the
                treatment assignment column. Defaults to None.
            target_roles (list[ABCRole] | None, optional): The role(s) defining
                the target outcome column(s). Defaults to None.
            key (Any, optional): Optional identifier for the operator instance.
                Defaults to "".
        """
        super().__init__(
            grouping_role=grouping_role, target_roles=target_roles, key=key
        )
    
    def _set_value(
            self, data: ExperimentData, value: Dataset, key=None
    ) -> ExperimentData:
        """
        Store the calculated bias values into the ExperimentData object.

        This method saves the bias estimates as additional fields in the
        ExperimentData, making them available for downstream operators
        (e.g., MatchingMetrics) to apply bias correction.

        Args:
            data (ExperimentData): The experiment data object to update.
            value (Dataset): The dataset containing bias estimates for
                treatment and/or control groups.
            key (Any, optional): Optional key for the stored value.
                Defaults to None.

        Returns:
            ExperimentData: The updated experiment data with bias values
                stored in the ``additional_fields`` space.
        """
        return data.set_value(
            space=ExperimentDataEnum.additional_fields,
            executor_id=self.id,
            value=value,
            role=value.roles,
        )
    
    @staticmethod
    def calc_bias(
        X: Dataset, X_matched: Dataset, coefficients: np.ndarray[float]
    ) -> list[float]:
        """
        Calculate bias as the dot product of feature differences and coefficients.

        Computes the residual bias by projecting the difference between
        original features (X) and matched (counterfactual) features
        (X_matched) onto the regression coefficients.

        The formula is: bias = (X - X_matched) · coefficients

        Args:
            X (Dataset): The original feature values for the group.
            X_matched (Dataset): The matched (counterfactual) feature values,
                typically computed by averaging over matched pairs.
            coefficients (np.ndarray[float]): The regression coefficients
                from the least-squares fit of target ~ features.

        Returns:
            list[float]: A list (or Dataset) containing the bias estimate
                for each observation in the group.

        Examples:
            ```python
                bias = Bias.calc_bias(
                    X=treatment_features,
                    X_matched=matched_features,
                    coefficients=regression_coefs
                )
            ```
        """
        return (X - X_matched).dot(coefficients)

    @classmethod
    def _inner_function(
        cls,
        data: Dataset,
        test_data: Dataset | None = None,
        target_fields: list[str] | None = None,
        features_fields: list[str] | None = None,
        **kwargs,
    ) -> dict:
        """
        Core calculation logic for bias estimation.

        Fits a linear regression model (target ~ features) for each group
        using the matched observations, then computes the bias as the
        difference between original and matched features projected onto
        the regression coefficients.

        The method handles three scenarios:
            1. Only control group has matched data → compute bias for control
            2. Only treatment group has matched data → compute bias for treatment
            3. Both groups have matched data → compute bias for both

        Args:
            data (Dataset): The baseline (control) dataset.
            test_data (Dataset | None, optional): The compared (treatment) dataset.
                Defaults to None.
            target_fields (list[str] | None, optional): Names of the target fields.
                The first element is the original target, the second is the
                matched target. Defaults to None.
            features_fields (list[str] | None, optional): Names of the feature fields.
                The first half are original features, the second half are
                matched features. Defaults to None.
            **kwargs: Additional keyword arguments (currently unused).

        Returns:
            dict: A dictionary with keys "test" and/or "control" mapping to
                the bias estimates (Dataset) for each group.

        Raises:
            NoneArgumentError: If any of the required arguments (target_fields,
                features_fields, test_data) are None.
        """
        if target_fields is None or features_fields is None or test_data is None:
            raise NoneArgumentError(
                ["target_fields", "features_fields", "test_data"], "bias_estimation"
            )
        if data[target_fields[1]].na_counts() > 0:
            coef_cls = backend_factory.resolve_backend(LstsqExtension, test_data)
            coefficients = coef_cls().calc(test_data[[target_fields[1]] + features_fields[len(features_fields) // 2 :]])
            return {
                "test": cls.calc_bias(
                    test_data[features_fields[: len(features_fields) // 2]],
                    test_data[features_fields[len(features_fields) // 2 :]],
                    coefficients,
                )
            }
        
        if test_data[target_fields[1]].na_counts() > 0:
            coef_cls = backend_factory.resolve_backend(LstsqExtension, data)
            coefficients = coef_cls().calc(data[[target_fields[1]] + features_fields[len(features_fields) // 2 :]])
            return {
                "control": cls.calc_bias(
                    data[features_fields[: len(features_fields) // 2]],
                    data[features_fields[len(features_fields) // 2 :]],
                    coefficients,
                )
            }
        coef_cls = backend_factory.resolve_backend(LstsqExtension, test_data)
        test_coefficients = coef_cls().calc(test_data[[target_fields[1]] + features_fields[len(features_fields) // 2 :]])

        coef_cls = backend_factory.resolve_backend(LstsqExtension, data)
        control_coefficients = coef_cls().calc(data[[target_fields[1]] + features_fields[len(features_fields) // 2 :]])
        return {
            "test": cls.calc_bias(
                test_data[features_fields[: len(features_fields) // 2]],
                test_data[features_fields[len(features_fields) // 2 :]],
                test_coefficients,
            ),
            "control": cls.calc_bias(
                data[features_fields[: len(features_fields) // 2]],
                data[features_fields[len(features_fields) // 2 :]],
                control_coefficients,
            ),
        }

    @classmethod
    def _execute_inner_function(
        cls,
        grouping_data,
        target_fields: list[str] | None = None,
        features_fields: list[str] | None = None,
        **kwargs,
    ) -> dict:
        """
        Execute the inner bias calculation on grouped data.

        This classmethod serves as a wrapper that unpacks the grouped data
        and delegates to ``_inner_function``.

        Args:
            grouping_data: Grouped dataset containing the control and treatment slices.
                Expected format: [(control_name, control_data), (test_name, test_data)]
            target_fields (list[str] | None, optional): Names of the target fields.
                Defaults to None.
            features_fields (list[str] | None, optional): Names of the feature fields.
                Defaults to None.
            **kwargs: Additional keyword arguments passed to ``_inner_function``.

        Returns:
            dict: The result of the ``_inner_function`` calculation, containing
                bias estimates for treatment and/or control groups.
        """
        return cls._inner_function(
            grouping_data[0][1],
            test_data=grouping_data[1][1],
            target_fields=target_fields,
            features_fields=features_fields,
            **kwargs,
        )

    def execute(self, data: ExperimentData) -> ExperimentData:
        """
        Execute the bias estimation on the given experiment data.

        This method orchestrates the entire bias calculation process:
            1. Retrieves grouping and target fields
            2. Prepares matched data if necessary (when second target is missing)
            3. Computes bias estimates for treatment and/or control groups
            4. Stores the results in the ExperimentData object

        The bias estimates are stored as additional fields with the role
        ``AdditionalStatisticRole``, making them available for downstream
        operators (e.g., ``MatchingMetrics``) to apply bias correction.

        Args:
            data (ExperimentData): The experiment data containing the matched
                dataset and match indices.

        Returns:
            ExperimentData: The updated ExperimentData object with bias estimates
                stored in the ``additional_fields`` space.

        Examples:
            ```python
                bias_calc = Bias(
                    grouping_role=TreatmentRole(),
                    target_roles=[TargetRole()]
                )
                result_data = bias_calc.execute(experiment_data)
                # Bias estimates are now in result_data.additional_fields
            ```
        """
        group_field, target_fields = self._get_fields(data)
        # t_data = deepcopy(data.initial_ds)
        # if len(target_fields) < 2:
        #     _, matched_data = self.prepare_data(data, t_data)
        #     target_fields += [matched_data.search_columns(TargetRole())[0]]
        #     t_data = t_data.add_column(matched_data)
        self.key = str(
            target_fields[0] if len(target_fields) == 1 else (target_fields or "")
        )
        if (
            not target_fields and data.initial_ds.tmp_roles
        ):  # if the column is not suitable for the test, then the target will be empty, but if there is a role tempo, then this is normal behavior
            return data  
        cls = backend_factory.resolve_backend(BiasExtension, data.ds)
        compare_result: Dataset = cls(self.grouping_role, self.target_roles).calc(data.ds)
        compare_result.roles["bias"] = AdditionalStatisticRole()
        compare_result.roles["matched_target"] = AdditionalTargetRole()

        output = self._set_value(data, compare_result)
        if compare_result.is_persisted:
            compare_result.unpersist()
        return output
