from __future__ import annotations
import fsspec
import uuid
import faiss
import os
import gc
import tempfile
import threading
import shutil
from typing import Optional
from collections import OrderedDict
from pyspark.sql import SparkSession
from pyspark import RDD, SparkFiles

class FaissIndexStorage:
    DISTRIBUTED_DIRS = []
    LOCAL_DIRS = []

    def __init__(
        self,
        sp_s: SparkSession,
        base_dir: Optional[str] = None 
    ):
        self.sp_s = sp_s
        self._distributed = False
        self._distributed_dir = None
        self._local_tmp_dir = None
        default_fs = self.define_fs(sp_s)
        
        if default_fs.startswith("file"):
            dir_id = uuid.uuid1().hex[:8]
            self._local_tmp_dir = f"__partition_indexes{dir_id}"
            os.makedirs(self._local_tmp_dir, exist_ok=True)
            FaissIndexStorage.LOCAL_DIRS.append(self._local_tmp_dir)
        else:
            self._distributed = True
            self._distributed_dir = (
                base_dir or
                f"{default_fs.rstrip('/')}/tmp/faiss_indexes_{uuid.uuid1().hex[:8]}"
            )
            FaissIndexStorage.DISTRIBUTED_DIRS.append(self._distributed_dir)

    @staticmethod
    def define_fs(session: SparkSession) -> str:
        """
        Определяет файловую систему из конфигурации Spark.
        Заменяет viewfs:// на hdfs:// для совместимости с fsspec (через pyarrow/libhdfs).
        """
        file_sys = None
        
        # First approach - через Hadoop Configuration
        try:
            hadoop_conf = session.sparkContext._jsc.hadoopConfiguration()
            file_sys = hadoop_conf.get("fs.defaultFS", "file:///")
            if file_sys == "file:///":
                file_sys = None
        except Exception:
            pass
            
        # Second approach - через Spark Conf
        if file_sys is None:
            try:
                file_sys = session.conf.get(
                    "spark.hadoop.fs.defaultFS",
                    session.conf.get("fs.defaultFS", "file:///")
                )
            except Exception:
                file_sys = "file:///"
                
        # Заменяем viewfs:// на hdfs://
        if file_sys and file_sys.startswith("viewfs://"):
            file_sys = FaissIndexStorage._convert_viewfs_to_hdfs(session, file_sys)
            
        return file_sys or "file:///"

    @staticmethod
    def _convert_viewfs_to_hdfs(session: SparkSession, viewfs_uri: str) -> str:
        """
        Конвертирует viewfs:// URI в hdfs:// URI.
        fsspec с бэкендом pyarrow (libhdfs) отлично работает с hdfs:// и 
        автоматически подхватывает HA-конфигурацию из hdfs-site.xml.
        """
        # viewfs://cluster_name/... -> hdfs://cluster_name/...
        hdfs_uri = viewfs_uri.replace("viewfs://", "hdfs://", 1)
        print(f"ℹ️ Converted viewfs to hdfs: {hdfs_uri}")
        return hdfs_uri

    @staticmethod
    def debug_filesystem(session: SparkSession) -> dict:
        """
        Отладочный метод для проверки файловой системы и fsspec.
        """
        results = {
            "spark_config": {},
            "hadoop_config": {},
            "detected_fs": None,
            "fsspec_protocols": [],
            "test_write": None,
            "test_read": None,
            "errors": []
        }
        print("=" * 80)
        print("🔍 FSSPEC FILESYSTEM DEBUG (HDFS / PyArrow mode)")
        print("=" * 80)
        
        # 1. Получаем конфигурацию Spark
        print("\n📋 Spark Configuration:")
        spark_configs = [
            "spark.hadoop.fs.defaultFS",
            "fs.defaultFS",
            "spark.master",
            "spark.app.name"
        ]
        for key in spark_configs:
            try:
                value = session.conf.get(key, "N/A")
                results["spark_config"][key] = value
                print(f"  {key}: {value}")
            except Exception as e:
                print(f"  {key}: ERROR - {e}")
                
        # 2. Получаем конфигурацию Hadoop
        print("\n📋 Hadoop Configuration:")
        try:
            hadoop_conf = session.sparkContext._jsc.hadoopConfiguration()
            hadoop_keys = [
                "fs.defaultFS",
                "dfs.nameservices",
                "dfs.namenode.rpc-address", # RPC важнее HTTP для hdfs://
                "fs.viewfs.impl",
                "fs.hdfs.impl"
            ]
            for key in hadoop_keys:
                try:
                    value = hadoop_conf.get(key, "N/A")
                    results["hadoop_config"][key] = value
                    print(f"  {key}: {value}")
                except Exception:
                    print(f"  {key}: N/A")
        except Exception as e:
            results["errors"].append(f"Failed to get Hadoop config: {e}")
            
        # 3. Определяем файловую систему
        print("\n🔎 Detecting Filesystem:")
        try:
            detected_fs = FaissIndexStorage.define_fs(session)
            results["detected_fs"] = detected_fs
            print(f"  Detected FS: {detected_fs}")
        except Exception as e:
            results["errors"].append(f"Failed to detect FS: {e}")
            print(f"  Error: {e}")
            
        # 4. Проверяем поддерживаемые протоколы fsspec
        print("\n📚 FSSpec Supported Protocols:")
        try:
            from fsspec.registry import known_implementations
            protocols = list(known_implementations.keys())
            results["fsspec_protocols"] = protocols
            print(f"  Total protocols: {len(protocols)}")
            print(f"  HDFS-related: {[p for p in protocols if 'hdfs' in p.lower() or 'web' in p.lower()]}")
        except Exception as e:
            results["errors"].append(f"Failed to get fsspec protocols: {e}")
            
        # 5. Тестируем подключение и чтение/запись
        if detected_fs and not detected_fs.startswith("file"):
            print("\n🧪 Testing FSSpec Connection:")
            try:
                fs, path = fsspec.core.url_to_fs(detected_fs)
                print(f"  ✅ Successfully created filesystem: {type(fs).__name__}")
                print(f"  Protocol: {fs.protocol}")
                
                # Формируем корректный URI для теста
                test_file_uri = f"{detected_fs.rstrip('/')}/tmp/fsspec_test_{uuid.uuid1().hex[:8]}.txt"
                print(f"  Attempting to write to: {test_file_uri}")
                
                # ИСПРАВЛЕНИЕ БАГА: Используем fsspec.open, чтобы он сам корректно 
                # разделил протокол и путь. Прямой вызов fs.mkdirs("hdfs://...") 
                # приводит к ошибке экранирования URL.
                with fsspec.open(test_file_uri, "w") as f:
                    f.write("fsspec hdfs debug test")
                results["test_write"] = "Success"
                print(f"  ✅ Write successful")
                
                with fsspec.open(test_file_uri, "r") as f:
                    content = f.read()
                results["test_read"] = content
                print(f"  ✅ Read successful: '{content}'")
                
                # Cleanup (используем _strip_protocol, чтобы передать в fs.rm чистый путь)
                clean_path = fs._strip_protocol(test_file_uri)
                fs.rm(clean_path)
                print(f"  ✅ Cleanup successful")
                
            except Exception as e:
                results["errors"].append(f"Connection test failed: {e}")
                print(f"  ❌ Test failed: {type(e).__name__}: {e}")
                import traceback
                traceback.print_exc()

        print("\n" + "=" * 80)
        if results["errors"]:
            print(f"❌ DEBUG COMPLETE - Found {len(results['errors'])} error(s)")
            for i, err in enumerate(results["errors"], 1):
                print(f"  {i}. {err}")
        else:
            print("✅ DEBUG COMPLETE - All checks passed")
        print("=" * 80)
        return results

    def __getstate__(self):
        state = self.__dict__.copy()
        if "sp_s" in state:
            del state["sp_s"]
        return state

    def save_index(self, index: faiss.Index):
        if self._distributed:
            uri = os.path.join(
                self._distributed_dir, f"index_{uuid.uuid1().hex[:8]}.faiss"
            )
            with fsspec.open(uri, "wb").open() as f:
                faiss.write_index(index, faiss.PyCallbackIOWriter(f.write))
            return uri
        else:
            return faiss.serialize_index(index)

    def collect_and_register(self, rdd: RDD):
        index_refs = []
        if self._distributed:
            index_refs = rdd.collect()
        else:
            for shard in rdd.toLocalIterator():
                partition_indexes = faiss.deserialize_index(shard)
                run_id = uuid.uuid1().hex[:8]
                index_file_name = f"__partition_index_{run_id}.index"
                faiss.write_index(
                    partition_indexes,
                    f"{self._local_tmp_dir}/{index_file_name}" 
                )    
                self.sp_s.sparkContext.addFile(f"{self._local_tmp_dir}/{index_file_name}")
                index_refs.append(index_file_name)
                del partition_indexes
                gc.collect()
        return index_refs

    def load_index(self, link: str) -> faiss.Index:
        if self._distributed:
            with tempfile.NamedTemporaryFile(
                delete=False, suffix=".faiss"
            ) as temp:
                load_temp = temp.name
            try:
                with fsspec.open(link, "rb").open() as f_in, \
                     open(load_temp, "wb") as f_out:
                    while True:
                        chunk = f_in.read(64 * 1024 * 1024)
                        if not chunk:
                            break
                        f_out.write(chunk)
                index = faiss.read_index(load_temp)
            finally:
                if os.path.exists(load_temp):
                    os.remove(load_temp)
            return index
        else:
            return faiss.read_index(SparkFiles.get(link))

    @staticmethod
    def cleanup():
        if FaissIndexStorage.DISTRIBUTED_DIRS:
            for dir in FaissIndexStorage.DISTRIBUTED_DIRS:
                try:
                    fs, _ = fsspec.core.url_to_fs(
                        dir, use_listings_cache=False
                    )
                    # ИСПРАВЛЕНИЕ: убираем протокол из строки перед удалением, 
                    # чтобы избежать багов парсинга пути внутри pyarrow/libhdfs
                    clean_dir = fs._strip_protocol(dir)
                    fs.rm(clean_dir, recursive=True)
                except Exception:
                    pass
        FaissIndexStorage.DISTRIBUTED_DIRS = []
        
        if FaissIndexStorage.LOCAL_DIRS:
            for dir in FaissIndexStorage.LOCAL_DIRS:
                if os.path.exists(dir):
                    shutil.rmtree(dir)
        FaissIndexStorage.LOCAL_DIRS = []


class CachingIndex:
    """
    LRU-кэш FAISS-индексов в памяти экзекьютора.
    Предотвращает повторную загрузку одного и того же индекса
    при обработке нескольких партиций.
    """
    def __init__(self, max_index: Optional[int] = None):
        self._max = max_index
        self._cache: OrderedDict = OrderedDict()
        self._lock = threading.Lock()

    def get(
        self,
        reference: str,
        storage: FaissIndexStorage,
        nprobe: int,
    ):
        with self._lock:
            if reference in self._cache:
                self._cache.move_to_end(key=reference)
                return self._cache[reference]
            if self._max and len(self._cache) >= self._max:
                _, evicted = self._cache.popitem(last=False)
                del evicted
                import gc; gc.collect()
            tmp_index = storage.load_index(reference)
            inner = faiss.downcast_index(tmp_index)
            if hasattr(inner, "nprobe"):
                inner.nprobe = nprobe
            self._cache[reference] = tmp_index
            return tmp_index