from __future__ import annotations
import fsspec
import uuid
import faiss
import os
import gc
import tempfile
import threading
import shutil
from typing import Optional
from collections import OrderedDict
from pyspark.sql import SparkSession
from pyspark import RDD, SparkFiles


class FaissIndexStorage:
    DISTRIBUTED_DIRS = []
    LOCAL_DIRS = []

    def __init__(
        self,
        sp_s: SparkSession,
        base_dir: Optional[str] = None
    ):
        self.sp_s = sp_s
        self._distributed = False
        self._distributed_dir = None
        self._local_tmp_dir = None
        default_fs = self.define_fs(sp_s)
        
        if default_fs.startswith("file"):
            dir_id = uuid.uuid1().hex[:8]
            self._local_tmp_dir = f"__partition_indexes{dir_id}"
            os.makedirs(self._local_tmp_dir, exist_ok=True)
            FaissIndexStorage.LOCAL_DIRS.append(self._local_tmp_dir)
        else:
            self._distributed = True
            self._distributed_dir = (
                base_dir or
                f"{default_fs.rstrip('/')}/tmp/faiss_indexes_{uuid.uuid1().hex[:8]}"
            )
            FaissIndexStorage.DISTRIBUTED_DIRS.append(self._distributed_dir)

    @staticmethod
    def define_fs(session: SparkSession) -> str:
        """
        Определяет файловую систему из конфигурации Spark.
        Заменяет viewfs:// на webhdfs:// для совместимости с fsspec.
        """
        file_sys = None
        
        # First approach - через Hadoop Configuration
        try:
            hadoop_conf = session.sparkContext._jsc.hadoopConfiguration()
            file_sys = hadoop_conf.get("fs.defaultFS", "file:///")
            if file_sys == "file:///":
                file_sys = None
        except Exception:
            pass
        
        # Second approach - через Spark Conf
        if file_sys is None:
            try:
                file_sys = session.conf.get(
                    "spark.hadoop.fs.defaultFS",
                    session.conf.get("fs.defaultFS", "file:///")
                )
            except Exception:
                file_sys = "file:///"
        
        # Заменяем viewfs:// на webhdfs:// для совместимости с fsspec
        if file_sys and file_sys.startswith("viewfs://"):
            # Извлекаем namenode из viewfs и конвертируем в webhdfs
            # viewfs://cluster/path -> webhdfs://namenode:port/path
            file_sys = FaissIndexStorage._convert_viewfs_to_webhdfs(session, file_sys)
        
        return file_sys or "file:///"

    @staticmethod
    def _convert_viewfs_to_webhdfs(session: SparkSession, viewfs_uri: str) -> str:
        """
        Конвертирует viewfs:// URI в webhdfs:// URI.
        Пытается получить реальный namenode из конфигурации Hadoop.
        """
        try:
            hadoop_conf = session.sparkContext._jsc.hadoopConfiguration()
            
            # Пытаемся получить dfs.nameservices
            nameservices = hadoop_conf.get("dfs.nameservices", "")
            
            if nameservices:
                # Для HA кластера - берем первый nameservice
                ns = nameservices.split(",")[0].strip()
                
                # Получаем namenodes для этого nameservice
                namenodes_key = f"dfs.ha.namenodes.{ns}"
                namenodes = hadoop_conf.get(namenodes_key, "")
                
                if namenodes:
                    # Берем первый namenode
                    nn = namenodes.split(",")[0].strip()
                    
                    # Получаем адрес namenode
                    nn_address_key = f"dfs.namenode.http-address.{ns}.{nn}"
                    nn_address = hadoop_conf.get(nn_address_key, "")
                    
                    if nn_address:
                        # Конвертируем path из viewfs
                        # viewfs://cluster/tmp/... -> webhdfs://namenode:port/tmp/...
                        path = viewfs_uri.split("viewfs://")[1].split("/", 1)
                        if len(path) > 1:
                            return f"webhdfs://{nn_address}/{path[1]}"
                        else:
                            return f"webhdfs://{nn_address}/"
            
            # Fallback: пробуем получить dfs.namenode.http-address напрямую
            nn_address = hadoop_conf.get("dfs.namenode.http-address", "")
            if nn_address:
                path = viewfs_uri.split("viewfs://")[1].split("/", 1)
                if len(path) > 1:
                    return f"webhdfs://{nn_address}/{path[1]}"
                else:
                    return f"webhdfs://{nn_address}/"
                    
        except Exception as e:
            print(f"⚠ Warning: Failed to convert viewfs to webhdfs: {e}")
        
        # Если не удалось конвертировать, возвращаем hdfs:// как fallback
        return viewfs_uri.replace("viewfs://", "hdfs://")

    @staticmethod
    def debug_filesystem(session: SparkSession, test_path: Optional[str] = None) -> dict:
        """
        Отладочный метод для проверки файловой системы и fsspec.
        Можно вызвать вне эксперимента для диагностики проблем.
        
        Args:
            session: SparkSession
            test_path: Опциональный путь для тестирования записи/чтения
            
        Returns:
            dict с результатами диагностики
        """
        results = {
            "spark_config": {},
            "hadoop_config": {},
            "detected_fs": None,
            "converted_fs": None,
            "fsspec_protocols": [],
            "test_write": None,
            "test_read": None,
            "errors": []
        }
        
        print("=" * 80)
        print("🔍 FSSPEC FILESYSTEM DEBUG")
        print("=" * 80)
        
        # 1. Получаем конфигурацию Spark
        print("\n📋 Spark Configuration:")
        try:
            spark_configs = [
                "spark.hadoop.fs.defaultFS",
                "fs.defaultFS",
                "spark.master",
                "spark.app.name"
            ]
            for key in spark_configs:
                try:
                    value = session.conf.get(key, "N/A")
                    results["spark_config"][key] = value
                    print(f"  {key}: {value}")
                except Exception as e:
                    print(f"  {key}: ERROR - {e}")
        except Exception as e:
            results["errors"].append(f"Failed to get Spark config: {e}")
            print(f"  ❌ Error: {e}")
        
        # 2. Получаем конфигурацию Hadoop
        print("\n📋 Hadoop Configuration:")
        try:
            hadoop_conf = session.sparkContext._jsc.hadoopConfiguration()
            hadoop_keys = [
                "fs.defaultFS",
                "dfs.nameservices",
                "dfs.namenode.http-address",
                "fs.viewfs.impl",
                "fs.webhdfs.impl"
            ]
            for key in hadoop_keys:
                try:
                    value = hadoop_conf.get(key, "N/A")
                    results["hadoop_config"][key] = value
                    print(f"  {key}: {value}")
                except Exception:
                    print(f"  {key}: N/A")
        except Exception as e:
            results["errors"].append(f"Failed to get Hadoop config: {e}")
            print(f"  ❌ Error: {e}")
        
        # 3. Определяем файловую систему
        print("\n🔎 Detecting Filesystem:")
        try:
            detected_fs = FaissIndexStorage.define_fs(session)
            results["detected_fs"] = detected_fs
            print(f"  Detected FS: {detected_fs}")
        except Exception as e:
            results["errors"].append(f"Failed to detect FS: {e}")
            print(f"  ❌ Error: {e}")
        
        # 4. Проверяем поддерживаемые протоколы fsspec
        print("\n📚 FSSpec Supported Protocols:")
        try:
            from fsspec.registry import known_implementations
            protocols = list(known_implementations.keys())
            results["fsspec_protocols"] = protocols
            print(f"  Total protocols: {len(protocols)}")
            print(f"  HDFS-related: {[p for p in protocols if 'hdfs' in p.lower() or 'web' in p.lower()]}")
        except Exception as e:
            results["errors"].append(f"Failed to get fsspec protocols: {e}")
            print(f"  ❌ Error: {e}")
        
        # 5. Тестируем fsspec с определенной ФС
        print("\n🧪 Testing FSSpec Connection:")
        if results["detected_fs"] and not results["detected_fs"].startswith("file"):
            try:
                fs, _ = fsspec.core.url_to_fs(
                    results["detected_fs"], 
                    use_listings_cache=False
                )
                print(f"  ✅ Successfully created filesystem: {type(fs).__name__}")
                print(f"  Protocol: {fs.protocol}")
                
                # Тестируем создание директории
                test_dir = f"{results['detected_fs'].rstrip('/')}/tmp/fsspec_test_{uuid.uuid1().hex[:8]}"
                try:
                    fs.mkdirs(test_dir, exist_ok=True)
                    print(f"  ✅ Successfully created test directory: {test_dir}")
                    
                    # Тестируем запись
                    test_file = f"{test_dir}/test.txt"
                    try:
                        with fsspec.open(test_file, "wb") as f:
                            f.write(b"test data")
                        print(f"  ✅ Successfully wrote test file: {test_file}")
                        results["test_write"] = "success"
                        
                        # Тестируем чтение
                        try:
                            with fsspec.open(test_file, "rb") as f:
                                data = f.read()
                            print(f"  ✅ Successfully read test file: {len(data)} bytes")
                            results["test_read"] = "success"
                        except Exception as e:
                            print(f"  ❌ Failed to read: {e}")
                            results["test_read"] = str(e)
                            results["errors"].append(f"Read test failed: {e}")
                        
                        # Cleanup
                        try:
                            fs.rm(test_dir, recursive=True)
                            print(f"  ✅ Cleanup successful")
                        except Exception as e:
                            print(f"  ⚠ Cleanup warning: {e}")
                            
                    except Exception as e:
                        print(f"  ❌ Failed to write: {e}")
                        results["test_write"] = str(e)
                        results["errors"].append(f"Write test failed: {e}")
                        
                except Exception as e:
                    print(f"  ❌ Failed to create directory: {e}")
                    results["errors"].append(f"Mkdir test failed: {e}")
                    
            except Exception as e:
                print(f"  ❌ Failed to create filesystem: {e}")
                results["errors"].append(f"FS creation failed: {e}")
        else:
            print("  ℹ Skipping test (local filesystem)")
        
        # 6. Итоговый отчет
        print("\n" + "=" * 80)
        if results["errors"]:
            print(f"❌ DEBUG COMPLETE - Found {len(results['errors'])} error(s)")
            for i, err in enumerate(results["errors"], 1):
                print(f"  {i}. {err}")
        else:
            print("✅ DEBUG COMPLETE - All checks passed")
        print("=" * 80)
        
        return results

    def __getstate__(self):
        state = self.__dict__.copy()
        if "sp_s" in state:
            del state["sp_s"]
        return state

    def save_index(self, index: faiss.Index):
        if self._distributed:
            uri = os.path.join(
                self._distributed_dir, f"index_{uuid.uuid1().hex[:8]}.faiss"
            )
            with fsspec.open(uri, "wb").open() as f:
                faiss.write_index(index, faiss.PyCallbackIOWriter(f.write))
            return uri
        else:
            return faiss.serialize_index(index)

    def collect_and_register(self, rdd: RDD):
        index_refs = []
        if self._distributed:
            index_refs = rdd.collect()
        else:
            for shard in rdd.toLocalIterator():
                partition_indexes = faiss.deserialize_index(shard)
                run_id = uuid.uuid1().hex[:8]
                index_file_name = f"__partition_index_{run_id}.index"
                faiss.write_index(
                    partition_indexes,
                    f"{self._local_tmp_dir}/{index_file_name}"
                )
                self.sp_s.sparkContext.addFile(f"{self._local_tmp_dir}/{index_file_name}")
                index_refs.append(index_file_name)
                del partition_indexes
                gc.collect()
        return index_refs

    def load_index(self, link: str) -> faiss.Index:
        if self._distributed:
            with tempfile.NamedTemporaryFile(
                delete=False, suffix=".faiss"
            ) as temp:
                load_temp = temp.name
            try:
                with fsspec.open(link, "rb").open() as f_in, \
                     open(load_temp, "wb") as f_out:
                    while True:
                        chunk = f_in.read(64 * 1024 * 1024)
                        if not chunk:
                            break
                        f_out.write(chunk)
                index = faiss.read_index(load_temp)
            finally:
                if os.path.exists(load_temp):
                    os.remove(load_temp)
            return index
        else:
            return faiss.read_index(SparkFiles.get(link))

    @staticmethod
    def cleanup():
        if FaissIndexStorage.DISTRIBUTED_DIRS:
            for dir in FaissIndexStorage.DISTRIBUTED_DIRS:
                try:
                    fs, _ = fsspec.core.url_to_fs(
                        dir, use_listings_cache=False
                    )
                    fs.rm(dir, recursive=True)
                except Exception:
                    pass
            FaissIndexStorage.DISTRIBUTED_DIRS = []
        if FaissIndexStorage.LOCAL_DIRS:
            for dir in FaissIndexStorage.LOCAL_DIRS:
                if os.path.exists(dir):
                    shutil.rmtree(dir)
            FaissIndexStorage.LOCAL_DIRS = []

class CachingIndex:
    """
    LRU-кэш FAISS-индексов в памяти экзекьютора.
    Предотвращает повторную загрузку одного и того же индекса
    при обработке нескольких партиций.
    """
    def __init__(self, max_index: Optional[int] = None):
        self._max = max_index
        self._cache: OrderedDict = OrderedDict()
        self._lock = threading.Lock()

    def get(
        self,
        reference: str,
        storage: FaissIndexStorage,
        nprobe: int,
    ):
        with self._lock:
            if reference in self._cache:
                self._cache.move_to_end(key=reference)
                return self._cache[reference]
            if self._max and len(self._cache) >= self._max:
                _, evicted = self._cache.popitem(last=False)
                del evicted
                import gc; gc.collect()
            tmp_index = storage.load_index(reference)
            inner = faiss.downcast_index(tmp_index)
            if hasattr(inner, "nprobe"):
                inner.nprobe = nprobe
            self._cache[reference] = tmp_index
            return tmp_index